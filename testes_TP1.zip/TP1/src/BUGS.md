# Bugs encontrados no lexer.l (validação com testes/)

## 1. Ciclo infinito no fim do ficheiro (crítico)
Regra: `<<EOF>> { /* fim de ficheiro */ }`
Sem `yyterminate()` (ou `return`), o scanner volta a tentar ler depois do EOF e nunca
termina. Resultado: o programa não imprime tokens nem o total e fica preso, em qualquer
ficheiro (inclusive vazio).
Correção: `<<EOF>> { yyterminate(); }`

## 2. Linhas contadas em dobro com CRLF (afeta a saída)
Regra: `\r\n { yylineno++; }`
Com `%option yylineno`, o flex já conta o `\n` dentro de `\r\n`. A ação soma mais uma,
e cada linha CRLF conta como duas. Afeta os números de linha nos testes (ex.: teste 06).
Correção: `\r\n { /* yylineno ja conta o \n */ }`

Versão corrigida: `src/lexer_corrigido.l` (só estas duas alterações).
Resultado: 8/8 testes passam com a versão corrigida.

## Notas menores (não afetam os testes)
- `input` e `yyunput` geram avisos `-Wunused-function` com `gcc -Wall`.
