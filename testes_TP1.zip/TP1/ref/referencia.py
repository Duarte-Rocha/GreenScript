#!/usr/bin/env python3
"""Lexer de referencia (Python), construido a partir da especificacao do README.
Gera os resultados esperados dos testes: uso  python3 referencia.py ficheiro.gs
Formato: 'linha CATEGORIA lexema' por token/erro (ordem de aparecimento) e
'Tokens: N | Erros lexicais: M' no fim. N conta apenas tokens validos."""
import re, sys

PALAVRAS = {"LIGAR","DESLIGAR","ABRIR","FECHAR","AQUECER","PARAR","REGAR",
            "ESPERAR","SE","SENAO","HUMIDADE","REPETIR"}
DELIM = {"(":"ABRE_PAR", ")":"FECHA_PAR", "{":"ABRE_CHAVETA", "}":"FECHA_CHAVETA",
         ",":"VIRGULA", ";":"PONTO_VIRG"}
OPS2 = {"<=":"MENOR_IGUAL", ">=":"MAIOR_IGUAL", "==":"IGUAL", "!=":"DIFERENTE"}
OPS1 = {"<":"MENOR", ">":"MAIOR"}
RE_CAND = re.compile(r"[A-Za-z0-9_-]+")
RE_ESTUFA = re.compile(r"EST-[A-Z]{2}[0-9]{2}\Z")
RE_INT = re.compile(r"(0|[1-9][0-9]*)\Z")

def analisar(texto):
    eventos = []          # (linha, categoria, lexema), na ordem do ficheiro
    tokens = erros = 0
    i, linha, n = 0, 1, len(texto)
    def tok(cat, lex):
        nonlocal tokens
        tokens += 1
        eventos.append((linha, cat, lex))
    def err(lex):
        nonlocal erros
        erros += 1
        eventos.append((linha, "ERRO_LEXICO", lex))
    while i < n:
        c = texto[i]
        if c == "\n":
            linha += 1; i += 1; continue
        if c in " \t\r":
            i += 1; continue
        if c == "#":                       # comentario ate fim de linha
            while i < n and texto[i] != "\n":
                i += 1
            continue
        two = texto[i:i+2]
        if two in OPS2:                    # maior casamento
            tok(OPS2[two], two); i += 2; continue
        if c in OPS1:
            tok(OPS1[c], c); i += 1; continue
        if c in "=!":                      # isolados nao sao operadores
            err(c); i += 1; continue
        if c in DELIM:
            tok(DELIM[c], c); i += 1; continue
        m = RE_CAND.match(texto, i)        # candidato lexical maximo
        if m:
            lex = m.group(0)
            if lex in PALAVRAS:
                tok("PALAVRA_RESERVADA", lex)
            elif RE_ESTUFA.match(lex):
                tok("ID_ESTUFA", lex)
            elif RE_INT.match(lex):
                tok("INTEIRO", lex)
            else:
                err(lex)                   # um unico erro por candidato
            i = m.end(); continue
        err(c); i += 1                     # caracter desconhecido (+, *, @, ...)
    return eventos, tokens, erros

if __name__ == "__main__":
    texto = open(sys.argv[1], "rb").read().decode("utf-8", errors="replace")
    eventos, t, e = analisar(texto)
    for (l, cat, lex) in eventos:
        print(f"{l} {cat} {lex}")
    print(f"Tokens: {t} | Erros lexicais: {e}")
