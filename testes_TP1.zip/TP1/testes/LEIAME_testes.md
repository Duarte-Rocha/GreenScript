# Testes do lexer GreenScript

Cada `NN_nome.gs` tem o ficheiro `NN_nome.esperado` com a saida esperada.

Formato de saida: `linha CATEGORIA lexema` por cada token ou erro (ordem do ficheiro),
seguido de `Tokens: N | Erros lexicais: M`.

Convencoes assumidas (confirmar com o enunciado):
- Erros lexicais sao impressos como `linha ERRO_LEXICO lexema` e **nao** entram em N.
- Um candidato lexical maximo (letras, algarismos, `-`, `_`) invalido gera um unico erro.
- `=` e `!` isolados geram erro; `==` e `!=` sao operadores.
- Comentarios (`#` ate ao fim da linha) e espacos/tabs/fins de linha nao geram tokens.
- Teste 6 usa fins de linha CRLF (deve contar como uma so linha).

Os resultados esperados foram gerados por `../ref/referencia.py`, um lexer de referencia
escrito a partir da especificacao do README.
