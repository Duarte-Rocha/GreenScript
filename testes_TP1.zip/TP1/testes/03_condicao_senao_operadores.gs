# Teste 3 - condicao com SENAO e todos os operadores relacionais (valido)
SE (HUMIDADE < 30) {
    REGAR(EST-AB12, 10);
} SENAO {
    PARAR(EST-AB12);
}
SE (HUMIDADE <= 30) { ABRIR(EST-AB12); }
SE (HUMIDADE > 70) { FECHAR(EST-AB12); }
SE (HUMIDADE >= 70) { FECHAR(EST-AB12); }
SE (HUMIDADE == 50) { ESPERAR(10); }
SE (HUMIDADE != 50) { ESPERAR(10); }
