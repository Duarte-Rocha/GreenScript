# Teste 6 - outros erros lexicais (ficheiro com fins de linha CRLF)
LIGAR(EST-A1);
ESPERAR(10+5);
REGAR(EST-AB12, 3*2);
PARAR(@EST-AB12);
ligar(EST-AB12);
EST-ab12;
123abc;
LIGAR_X();
EST-AB123;
