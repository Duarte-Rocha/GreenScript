# Teste 5 - erros lexicais: = e ! isolados
LIGAR(EST-AB12);
SE (HUMIDADE = 30) { ESPERAR(1); }
SE (HUMIDADE ! 30) { ESPERAR(2); }
ABRIR(EST-AB12) ! ;
