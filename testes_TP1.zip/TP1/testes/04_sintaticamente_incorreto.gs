# Teste 4 - tokens validos em sequencia sintaticamente incorreta
LIGAR();
ESPERAR ABRIR 10 ) ;
{ { } SE SENAO , , ;
EST-AB12 ( 0 ) REGAR
