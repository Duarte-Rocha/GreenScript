# Teste 2 - espera (valido)
ESPERAR(5);
ESPERAR(120);
ESPERAR(0);
